# Telegram bot для отправки файла

## Файлы проекта

- `bot.py` — код Telegram-бота
- `requirements.txt` — зависимости
- `xeno.zip.zip` — файл, который бот отправляет пользователю

## Как запустить на компьютере

1. Установите зависимости:

```bash
python -m pip install -r requirements.txt
```

2. Запустите бота:

```bash
set BOT_TOKEN=ВАШ_ТОКЕН_БОТА
python bot.py
```

## Как запустить на Render

1. Зарегистрируйтесь на https://render.com
2. Создайте новый проект: New → Web Service
3. Загрузите проект на GitHub и подключите репозиторий к Render
4. В настройках укажите:

Build Command:

```bash
pip install -r requirements.txt
```

Start Command:

```bash
python bot.py
```

5. В Environment Variables добавьте:

```text
BOT_TOKEN = ваш токен от BotFather
```

6. Нажмите Deploy

После запуска бот будет работать без вашей консоли.
