import os
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes

# Токен берется из переменной окружения BOT_TOKEN
TOKEN = os.getenv("BOT_TOKEN")

# Файл, который бот будет отправлять
FILE_NAME = "xeno.zip.zip"


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("Скачать Xeno", callback_data="download_file")]
    ]

    await update.message.reply_text(
        "Привет! Нажмите кнопку ниже, чтобы скачать файл 👇",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def download_file(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    file_path = Path(FILE_NAME)

    if not file_path.exists():
        await query.message.reply_text("Файл не найден на сервере.")
        return

    with open(file_path, "rb") as file:
        await query.message.reply_document(
            document=file,
            filename=FILE_NAME,
            caption="Ваш файл готов для скачивания 👇"
        )


def main():
    if not TOKEN:
        raise RuntimeError("Не найден BOT_TOKEN. Добавьте токен бота в переменные окружения.")

    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(download_file, pattern="download_file"))

    print("Бот запущен...")
    app.run_polling()


if __name__ == "__main__":
    main()
